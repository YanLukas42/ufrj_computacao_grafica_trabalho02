/**
 * Neural Flux 3D
 * Um ambiente interativo simulando um fluxo de dados.
 */

let angle = 0;
let cubes = [];

function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
  // Gerando posições aleatórias para os "bits" de dados ao redor
  for (let i = 0; i < 50; i++) {
    cubes.push({
      x: random(-500, 500),
      y: random(-500, 500),
      z: random(-500, 500),
      size: random(5, 15),
      speed: random(0.01, 0.05)
    });
  }
}

function draw() {
  background(10, 15, 25); // Azul marinho profundo/quase preto
  
  // Controle de câmera com o mouse
  orbitControl();
  
  // Iluminação
  ambientLight(60);
  pointLight(0, 255, 150, 200, -200, 300); // Luz esverdeada (Matrix vibes)
  pointLight(150, 0, 255, -200, 200, 300); // Luz roxa/cyberpunk
  
  push();
  rotateY(angle);
  rotateX(angle * 0.5);
  
  // Núcleo Central: Esfera de Geometria
  noFill();
  stroke(0, 255, 180);
  strokeWeight(1);
  sphere(120, 24, 16); // Esfera wireframe
  
  // Segundo wireframe interno para efeito de "pulso"
  stroke(255, 255, 255, 50);
  sphere(125 + sin(frameCount * 0.05) * 5); 
  pop();
  
  // Grade de Perspectiva (O "Chão" do Sistema)
  push();
  translate(0, 400, 0);
  rotateX(HALF_PI);
  drawGrid();
  pop();
  
  // Bits de Dados Flutuantes
  drawDataStream();
  
  angle += 0.01;
}

function drawGrid() {
  stroke(0, 255, 150, 40);
  strokeWeight(1);
  for (let i = -1000; i <= 1000; i += 50) {
    line(i, -1000, i, 1000);
    line(-1000, i, 1000, i);
  }
}

function drawDataStream() {
  noStroke();
  fill(0, 255, 180, 150);
  
  cubes.forEach((c, index) => {
    push();
    // Movimento orbital simples
    let r = 300 + index * 2;
    let x = cos(frameCount * c.speed + index) * r;
    let z = sin(frameCount * c.speed + index) * r;
    translate(x, c.y, z);
    rotateX(frameCount * 0.02);
    box(c.size);
    pop();
  });
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}